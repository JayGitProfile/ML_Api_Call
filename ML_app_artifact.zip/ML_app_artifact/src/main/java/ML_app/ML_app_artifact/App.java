package ML_app.ML_app_artifact;


import java.io.IOException;
import org.apache.http.client.fluent.*;
import org.apache.http.entity.ContentType;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class App {
    // Handle making the request
    public static void sendRequest(String data) {
        // Replace with the scoring_uri of your service
    	System.out.println("Inside function");
        String uri = "https://ussouthcentral.services.azureml.net/workspaces/50535f49080c4b0f935185a0d773a649/services/6149fae9b3864c0bb89b4734280dd31f/execute?api-version=2.0&details=true";
        // If using authentication, replace with the auth key
        String key = "KJ5j/kg6ZWVsS2UJGFyFTk9iMtFt/KDRyypNvGWacpTPn+XJYlqb7f2NXFH4joTOP20jOzDJR6uSf467GfqsfA==";
        try {
            // Create the request
            Content content = Request.Post(uri)
            .addHeader("Content-Type", "application/json")
            // Only needed if using authentication
            .addHeader("Authorization", "Bearer " + key)
            // Set the JSON data as the body
            .bodyString(data, ContentType.APPLICATION_JSON)
            // Make the request and display the response.
            .execute().returnContent();
            System.out.println(content);
        }
        catch (IOException e) {
            System.out.println(e);
        }
    }
    public static void main(String[] args) {
        // Create the data to send to the service
    	  JSONObject obj4 = new JSONObject();
        JSONObject obj = new JSONObject();
        JSONObject obj2 = new JSONObject();
        JSONObject obj3 = new JSONObject();
      
        // In this case, it's an array of arrays
        JSONArray dataItems = new JSONArray();
        // Inner array has 10 elements
        System.out.println("Inside main");
     
        JSONArray item1 = new JSONArray();
        JSONArray ColumnNames = new JSONArray();
        ColumnNames.add("State_Name");
        ColumnNames.add("District_Name");
        ColumnNames.add("Season");
        ColumnNames.add("Crop");
        ColumnNames.add("Area");
        ColumnNames.add("Max_temp");
        ColumnNames.add("PH");
        ColumnNames.add("Humidity");
        ColumnNames.add("Production");
        item1.add("Telangana");
        item1.add("Adilabad");
        item1.add("Autumn");
        item1.add("Dry chillies");
        item1.add("456");
        item1.add("31");
        item1.add("6.47");
        item1.add("94");
        item1.add("0");
        dataItems.add(item1);
        
       // 
        obj.put("ColumnNames", ColumnNames);
        obj.put("Values", item1);
        obj2.put("input1", obj);
       //obj3.put
        obj3.put("Inputs", obj2);
        obj3.putIfAbsent("GlobalParameters",obj4);
        //obj3.put("GlobalParameters","{}");
        //obj3.
        System.out.println(obj3.toJSONString());
        //String data ="{\"data\":[\"Telangana\",\"Adilabad\",\"Autumn\",\"Dry chillies\",\"456\",\"31\",\"6.47\",\"94\",\"0\"]}";
        //System.out.println(data);
        
        // Make the request using the JSON document string
       //sendRequest(obj3.toJSONString());
        //sendRequest(data);
    }
}